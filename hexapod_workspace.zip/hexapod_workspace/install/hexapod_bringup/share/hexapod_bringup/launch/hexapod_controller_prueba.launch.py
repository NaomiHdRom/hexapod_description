def generate_launch_description():
    
    gazebo = ExecuteProcess(
        cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so',
             os.path.join(get_package_share_directory('hexapod_bringup'), 'world', 'test_w_1.world')],
        output='screen'
    )

    package_path = os.path.join(get_package_share_directory('hexapod_description'))
    xacro_file = os.path.join(package_path, 'urdf', 'hexapod_controller.xacro')
    rviz_config_path = os.path.join(package_path, 'rviz', 'urdf.rviz')

    doc = xacro.parse(open(xacro_file))
    xacro.process_doc(doc)
    params = {'robot_description': doc.toxml()}    

    controller_node = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[
            params,
            os.path.join(package_path, "config", "hexapod_legs_controller.yaml")
        ],
        output="screen"
    )

    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[params]
    )

    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', 'hexapod'],
        output='screen'
    )

    load_joint_state_controller = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'joint_state_broadcaster'],
        output='screen'
    )

    hexapod_control = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["hexapod_legs_controller"],
        output="screen"
    )

    config_arg = DeclareLaunchArgument(name='rvizconfig', default_value=rviz_config_path)
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        output='screen',
        arguments=['-d', LaunchConfiguration('rvizconfig')]
    )

    return LaunchDescription([
        config_arg,
        gazebo,
        controller_node,
        node_robot_state_publisher,
        spawn_entity,
        RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=spawn_entity,
                on_exit=[load_joint_state_controller],
            )
        ),
        RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=load_joint_state_controller,
                on_exit=[hexapod_control],
            )
        ),
        rviz_node
    ])
