#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from builtin_interfaces.msg import Duration
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
import time

class HexapodGait(Node):

    def __init__(self):
        super().__init__('hexapod_gait_controller')
        topic_name = "/hexapod_legs_controller/joint_trajectory"
        self.trajectory_publisher = self.create_publisher(JointTrajectory, topic_name, 10)

        self.joints = [
            'leg1_jointA', 'leg1_jointB', 'leg1_jointC',
            'leg2_jointA', 'leg2_jointB', 'leg2_jointC',
            'leg3_jointA', 'leg3_jointB', 'leg3_jointC',
            'leg4_jointA', 'leg4_jointB', 'leg4_jointC',
            'leg5_jointA', 'leg5_jointB', 'leg5_jointC',
            'leg6_jointA', 'leg6_jointB', 'leg6_jointC'
        ]

        # Gait trípode: alternancia entre dos grupos de patas
        self.gait_positions = [
            # Estado 1: patas 1, 4, 5 levantan; el resto soportan
            [
                -1.0, 0, 0,   # leg1 - levantada
                 0.0, 0, 0,   # leg2 - soporte
                 0.0, 0, 0,   # leg3 - soporte
                -1.0, 0, 0,   # leg4 - levantada
                -1.0, 0, 0,   # leg5 - levantada
                 0.0, 0, 0    # leg6 - soporte
            ],
            # Estado 2: patas 2, 3, 6 levantan; el resto soportan
            [
                 0.0, 0, 0,   # leg1 - soporte
                -1.0, 0, 0,   # leg2 - levantada
                -1.0, 0, 0,   # leg3 - levantada
                 0.0, 0, 0,   # leg4 - soporte
                 0.0, 0, 0,   # leg5 - soporte
                -1.0, 0, 0    # leg6 - levantada
            ]
        ]

        self.current_index = 0
        self.trajectory_active = False
        self.timer = self.create_timer(2.0, self.timer_callback)

        self.get_logger().info("Hexapod gait controller initialized.")

    def timer_callback(self):
        if not self.trajectory_active:
            positions = self.gait_positions[self.current_index]
            self.publish_trajectory(positions)
            self.current_index = (self.current_index + 1) % len(self.gait_positions)
            self.trajectory_active = True

    def publish_trajectory(self, positions):
        trajectory_msg = JointTrajectory()
        trajectory_msg.joint_names = self.joints

        point = JointTrajectoryPoint()
        point.positions = [float(p) for p in positions]
        point.time_from_start = Duration(sec=1)
        trajectory_msg.points.append(point)

        self.trajectory_publisher.publish(trajectory_msg)
        self.get_logger().info(f"Published gait step {self.current_index + 1}")
        self.create_timer(1.5, self.trajectory_complete_callback)

    def trajectory_complete_callback(self):
        self.trajectory_active = False

def main(args=None):
    rclpy.init(args=args)
    node = HexapodGait()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
